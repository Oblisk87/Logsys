
// JavaScript code for frontend functionalities

async function login() {
    const username = document.getElementById('username').value;
    const password = document.getElementById('password').value;

    const response = await fetch('/login', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify({ username, password })
    });

    if (response.ok) {
        const data = await response.json();
        if (data.message === 'Login successful') {
            window.location.href = '/dashboard';
        } else {
            alert('Login failed: ' + data.detail);
        }
    } else {
        alert('Login failed: ' + response.statusText);
    }
}

function logout() {
    window.location.href = '/';
}

async function fetchUsers() {
    console.log("Fetching users...");
    const response = await fetch('/users');
    const users = await response.json();
    console.log("Users fetched:", users);
    const userList = document.getElementById('user-list');
    userList.innerHTML = '';
    users.forEach(user => {
        const userItem = document.createElement('div');
        userItem.textContent = `Username: ${user.username}, Email: ${user.email}, Status: ${user.status}`;
        userList.appendChild(userItem);
    });
}

async function searchUser() {
    const query = document.getElementById('search-user').value;
    const response = await fetch(`/users?query=${query}`);
    const users = await response.json();
    const userList = document.getElementById('user-list');
    userList.innerHTML = '';
    users.forEach(user => {
        const userItem = document.createElement('div');
        userItem.textContent = `Username: ${user.username}, Email: ${user.email}, Status: ${user.status}`;
        userList.appendChild(userItem);
    });
}

async function fetchLogs() {
    console.log("Fetching logs...");
    const response = await fetch('/logs');
    const logs = await response.json();
    console.log("Logs fetched:", logs);
    const logList = document.getElementById('log-list');
    logList.innerHTML = '';
    logs.forEach(log => {
        const logItem = document.createElement('div');
        logItem.textContent = `Date: ${log.date}, Resource: ${log.resource_name}, Category: ${log.category}, Message: ${log.message}, Level: ${log.level}`;
        logList.appendChild(logItem);
    });
}

async function searchLog() {
    const query = document.getElementById('search-log').value;
    const response = await fetch(`/logs?query=${query}`);
    const logs = await response.json();
    const logList = document.getElementById('log-list');
    logList.innerHTML = '';
    logs.forEach(log => {
        const logItem = document.createElement('div');
        logItem.textContent = `Date: ${log.date}, Resource: ${log.resource_name}, Category: ${log.category}, Message: ${log.message}, Level: ${log.level}`;
        logList.appendChild(logItem);
    });
}

// Fetch users and logs on page load
window.onload = function() {
    fetchUsers();
    fetchLogs();
}
